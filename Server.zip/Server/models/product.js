/*const mongoose = require ("mongoose");

const productSchema = new Mongoose.Schema({
    name: String,
    type: String
});

const Product = mongoose.model('Product',productSchema);

module.exports = Product;*/
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    name: String,
    type: String,
    quantity: Number 
});

module.exports = mongoose.model('Product', productSchema);
