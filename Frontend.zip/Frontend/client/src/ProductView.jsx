import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './styles.css';
import logo from './logo192.png'; // Import your logo image

const ProductView = () => {
    const [products, setProducts] = useState([]);
    const [newProduct, setNewProduct] = useState({ name: '', type: '', quantity: '' });
    const [searchTerm, setSearchTerm] = useState('');
    const [error, setError] = useState('');
    const [updateId, setUpdateId] = useState(null); // State to hold the ID of the product to be updated

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const response = await axios.get('http://localhost:3000/product');
            setProducts(response.data.product);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    };

    const handleCreateProduct = async () => {
        if (!newProduct.name || !newProduct.type || !newProduct.quantity) {
            setError('Please fill out all fields');
            return;
        }
        if (isNaN(newProduct.quantity)) {
            setError('Quantity must be a number');
            return;
        }
        try {
            await axios.post('http://localhost:3000/product', newProduct);
            setNewProduct({ name: '', type: '', quantity: '' });
            setError('');
            fetchProducts();
        } catch (error) {
            console.error('Error creating product:', error);
        }
    };

    const handleUpdateProduct = async () => {
        if (!newProduct.name || !newProduct.type || !newProduct.quantity) {
            setError('Please fill out all fields');
            return;
        }
        if (isNaN(newProduct.quantity)) {
            setError('Quantity must be a number');
            return;
        }
        try {
            await axios.put(`http://localhost:3000/product/${updateId}`, newProduct);
            setNewProduct({ name: '', type: '', quantity: '' });
            setError('');
            fetchProducts();
            setUpdateId(null); // Reset update ID after updating
        } catch (error) {
            console.error('Error updating product:', error);
        }
    };

    const handleDeleteProduct = async (id) => {
        try {
            await axios.delete(`http://localhost:3000/product/${id}`);
            fetchProducts();
        } catch (error) {
            console.error('Error deleting product:', error);
        }
    };

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleUpdateClick = (product) => {
        setNewProduct(product);
        setUpdateId(product._id);
    };

    const filteredProducts = products.filter((product) =>
        product.name && product.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <header className="navbar">
                <nav>
                    <h1>Product Management</h1>
                    <img src={logo} alt="Logo" className="logo" /> {/* Add logo here */}
                    <ul className="nav-links">
                        <li><a href="/">Home</a></li>
                    </ul>
                </nav>
            </header>
            <aside className="sidebar">
                <ul>
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Products</a></li>
                    <li><a href="#">Orders</a></li>
                    <li><a href="#">Customers</a></li>
                </ul>
            </aside>
            <div className="container">
                <main>
                    <section className="create-product">
                        <h2>{updateId ? 'Update Product' : 'Create New Product'}</h2>
                        <div className="form-group">
                            <input
                                type="text"
                                placeholder="Name"
                                value={newProduct.name}
                                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                            />
                        </div>
                        <div className="form-group">
                            <input
                                type="text"
                                placeholder="Type"
                                value={newProduct.type}
                                onChange={(e) => setNewProduct({ ...newProduct, type: e.target.value })}
                            />
                        </div>
                        <div className="form-group">
                            <input
                                type="text"
                                placeholder="Quantity"
                                value={newProduct.quantity}
                                onChange={(e) => setNewProduct({ ...newProduct, quantity: e.target.value })}
                            />
                        </div>
                        <button onClick={updateId ? handleUpdateProduct : handleCreateProduct}>
                            {updateId ? 'Update Product' : 'Create Product'}
                        </button>
                        {error && <p className="error">{error}</p>}
                    </section>
                    <section className="search">
                        <h2>Search Products</h2>
                        <input
                            type="text"
                            placeholder="Search by product name"
                            value={searchTerm}
                            onChange={handleSearch}
                        />
                                    </section>
                                    <section className="product-list">
                    <h2>Product List</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Quantity</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredProducts.map((product) => (
                                <tr key={product._id}>
                                    <td>{product.name}</td>
                                    <td>{product.type}</td>
                                    <td>{product.quantity}</td>
                                    <td>
                                        <button onClick={() => handleUpdateClick(product)}>Update</button>
                                        <button onClick={() => handleDeleteProduct(product._id)}>Delete</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </section>

                </main>
            </div>
        </div>
    );
};

export default ProductView;
 