import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Import Routes
import ProductView from './ProductView';

const App = () => {
    return (
        <Router>
            <div>
                <Routes> {/* Wrap Route components in Routes */}
                    <Route exact path="/" element={<ProductView />} /> {/* Use 'element' prop */}
                    {/* Add more routes as needed */}
                </Routes>
            </div>
        </Router>
    );
};

export default App;
